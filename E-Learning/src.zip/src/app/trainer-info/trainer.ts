import { Course } from "../course-info/course"

export class Trainer {
    trainerId: string=""
    trainerName: string=""
    qualification: string=""
    phoneNumber: string=""
    address: string=""
    courseObj:Course=new Course();
}
