export class Feedback{
    feedbackId!: string
    feedbackDate!: Date
    comments!: string
    rating!: number
    enrollmentId!: string
    

}