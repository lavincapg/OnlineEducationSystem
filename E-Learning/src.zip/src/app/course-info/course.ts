export class Course{
  //[x: string]: any;
    courseId: string = '';
  courseName: string = '';
  duration: number = 0;
  category: string = '';
  

}