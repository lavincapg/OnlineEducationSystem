export class Student{
    
    studentId!:string;
    studentname!: string;
    city!: string;
    phoneNumber!: string;
    emailId!: string;
    dob!: Date;
   

}